
<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<?php
if(isset($_GET['error']))
{
   $text=$_GET['error'];

  ?>
  <font size="+2">
  <div onclick="this.style.display='none';" style="padding:20px;background-color:#66CCFF;color:#000000">
  <strong><?php echo $text; ?></strong>
  <input  type="submit" name="submit" value="OK" />
  
  </div>
  </font>
  <?php
  
}
?>
<?php 
extract($_REQUEST);
$id;
?>
<form id="f1" method="post" enctype="multipart/form-data" action="profile.php">
<?php
$qry="select * from users,tbl_district,tbl_city where users.district=tbl_district.distid and users.city=tbl_city.cityid and users.id='$uid'";

  $res=setData($qry);
  while($row1=mysqli_fetch_array($res))
  {


$fname=$row1['first_name'];
$lname=$row1['last_name'];	
$email=$row1['email'];
$district=$row1['district'];
$city=$row1['city'];	
$phone=$row1['phone'];
$street=$row1['street'];
$image=$row1['image'];


?>
<link href="css1/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css1/style.css" rel='stylesheet' type='text/css' />

<!-- Graph CSS -->
<link href="css1/font-awesome.css" rel="stylesheet">

<!-- jQuery -->



 
	
	<div class="container" style="background-color:#CCFFFF; width:1350px; height:1000px">
	<div class="send-button">
			<input type="hidden" value="<?php echo $uid?>" name="id" />
                <input  type="submit" name="submit" value="Edit your Profile" style=" padding: 10px 10px 10px 10px;font-size: 20px;float:right;display: block;width: 20%;">
            </div>
	<center>
<h2><font color="#000000">My Profile</font></h2>

<br><br>
<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/oh-autoval-style.css">
	<script src="../js/jquery.min.js"></script>
	<script src="../js/oh-autoval-script.js"></script>
    <div class="regisFrm">
		<form onSubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
		 <td><img src="../images/<?php echo $image;?>"style="width:200px; height:200px;" />&nbsp;</td><br />
		<label style="display:inline-block"><span class="username"><font color="#000000">First Name:</font></span></label>
		<input type="text" name="first_name" id="first_name" value="<?php echo $fname; ?>"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display:inline-block;width: 20%;"  required="" disabled="disabled"><br>
		
			
			<div class="username">
				<label><span class="username"><font color="#000000">Last Name:</font></span></label>
				 <input type="text" name="last_name" id="last_name" value="<?php echo $lname; ?>"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 20%;"  required="" disabled="disabled">
				<div class="clearfix"></div>
			</div>
			<div class="username">
				<label><span><font color="#000000">Email:<font color="#CCFFFF">vvvv</font></font></span></label>
				<input type="email" class="av-email" value="<?php echo $email; ?>"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 20%;"  required="" disabled="disabled">
				<div class="clearfix"></div>
			</div>
			<div class="username">
				
				
       <label><span class="username"><font color="#000000">District:<font color="#CCFFFF">vv</font></font></span></label>
        <?php
	$qry="select * from tbl_district where distid='$district'";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
	<input type="text" name="district" id="district" class="name" value="<?php echo $row[1];?>"   style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;color:#000000;width: 20%;"  required="" disabled="disabled">
        
        <?php
	}
	?>
        
				
				<div class="clearfix"></div>
			</div>
			<br>
			<div class="username">
				
				
	   
	   <label><span class="username"><font color="#000000">City:<font color="#CCFFFF">vvvv.</font></font></span></label>
        <?php
		//$cid=$_POST['did'];
	$qry="SELECT * FROM tbl_city WHERE cityid='$city' ";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
	<input type="text" name="city" id="city" value="<?php echo $row[2];?>" style="outline: none; padding: 10px 10px 10px 10px;font-size: 14px;color:#000000;display: inline-block;width: 20%;"  required=""  disabled="disabled">
	 
	<?php
	}
	?>
                   
					
                      
					<br>
		
				<div class="clearfix"></div>
			</div>
			<div class="username">
				<label><span class="username"><font color="#000000">Street:<font color="#CCFFFF">vv</font></font></span></label>
				<input type="text" name="phone" id="phone"  value="<?php echo $street; ?>"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 20%;"  required="" disabled="disabled">
				
				<div class="clearfix"></div>
			</div>
			<br>
			
			<div class="username">
				<label><span class="username"><font color="#000000">Phone:<font color="#CCFFFF">vv</font></font></span></label>
				<input type="text" name="phone" id="phone"  value="<?php echo $phone; ?>" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 20%;"  required="" disabled="disabled">
				
				<div class="clearfix"></div>
			</div>
			<br>
			
			<div class="clearfix"></div>
			
			<br>
			<?php }?>
		</form>
		
				
	</div>
	</div>
	</div>
</body>
</html>