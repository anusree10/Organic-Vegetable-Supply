
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_upload where id=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:viewpicture.php');

?>