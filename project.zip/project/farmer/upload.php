<?php
session_start();
//include '../query.php';
$fid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>

<html>
<head>

<link href="style.css" rel="stylesheet" type="text/css">
<h2><center><font color="#993300">Upload your cultivation pictures</font></center></h2>
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm"><br>
    <center>
        <form onSubmit="return" class="oh-autoval-form" method="post" id="frm-image-upload" style="width:500px;" enctype="multipart/form-data">

   
        <div class="form-row">
            <div>Choose Image file:</div>
            <div>
			<input type="file" name="image" id="image" class=" file-input av-image" av-message="Image validation">
               
            </div>
        </div>

        <div class="button-row">
            <input type="submit" id="btn-submit" name="submit"
                value="Upload">
				
        </div>
		
    </form>
	</div>
	</div>
   <br><br>
	
</body>
<footer class="py-5">
<div class="slide-imaes">

	</div>
	</footer>
	</html>
	<?php
$con=mysqli_connect("localhost","root","","store");

if(isset($_POST['submit']))
{
extract($_POST);
$y=$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],"images/".$y);
$qry="insert into tbl_upload(farmer_id,img_name) values('$fid','$y')";
$res=mysqli_query($con,$qry);
echo "<script>window.onload=function(){alert('Image added....!');window.location='upload.php';}</script>";
}
?>


