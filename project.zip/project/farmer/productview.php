<?php
session_start();
//include '../query.php';
$fid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>

<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#66CC66;
}
</style>				<!-- tables -->
	<link rel="stylesheet" href="css/table-style.css"> 
	<center> 			
				<div class="agile-tables">
				<div style="width:80%;">
					<div class="w3l-table-info">
					  <center><h2>Product View</h2></center>
					    <table border="0" id="table">
						<thead>
						  <tr>
							<th>Product No</th>
							<th>Category Name</th>
							<th>Quantity</th>
							<th>Product Name</th>
							<th>Description</th>
							
							<th>Price</th>
							<th>Image</th>
							<th>Operations</th>
						  </tr>
						</thead>
						 <?php
  //include('../query.php');
  $con=mysqli_connect("localhost","root","","store");
  $qry="select * from products,tbl_category where products.catid=tbl_category.catid and products.farid='$fid'";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row['category'];?>&nbsp;</td>
	 <td><?php echo $row[3];?>&nbsp;</td>
	  <td><?php echo $row[4];?>&nbsp;</td>
	   <td><?php echo $row['product_desc'];?>&nbsp;</td>
	    <td><?php echo $row['price'];?>&nbsp;</td>
	 <td><img src="images/<?php echo $row['product_img_name'];?>"width="100px" height="100px" />&nbsp;</td>
	   <td><span class="style2 style1">
     <a href="editproduct.php?id=<?php echo $row[0];?>"><input type="submit" name="edit" value="EDIT" /></a> &nbsp;
	 <br> <br> 
	  <a href="deleteproduct.php?id=<?php echo $row[0];?>"><input type="submit" name="delete" value="DELETE" /></a>
      &nbsp;</span></td>
  </tr>
  <?php $c++;
  }
  ?>
					  </table>
					</div>
				  
		
				 

				</div>
				<!-- //tables -->
			</div>
<!-- script-for sticky-nav -->
		