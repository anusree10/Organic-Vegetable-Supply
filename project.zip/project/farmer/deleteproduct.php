
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from products where id=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:productview.php');

?>