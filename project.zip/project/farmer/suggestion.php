<?php
session_start();
//include '../query.php';
$fid=$_SESSION['id'];

include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC99;
}
</style>

 <link rel="stylesheet" href="css/table-style.css">  
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2>User's doubts and suggestions</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							<th>User Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Operation</th>
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_contact,users where tbl_contact.user_id=users.id and tbl_contact.far_id='$fid'";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row['first_name']; echo $row['last_name'];?>&nbsp;</td>
	<td><?php echo $row['email'];?>&nbsp;</td>
	<td><?php echo $row['text'];?>&nbsp;</td>
	<td><span class="style2 style1">
     <a href="reply.php?uid=<?php echo $row['user_id'];?>&fid=<?php echo $fid;?>"><input type="submit" name="reply" value="REPLY" /></a> &nbsp;
	</td>
	  
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						
						</div>
						</div>
					
						</div>
						