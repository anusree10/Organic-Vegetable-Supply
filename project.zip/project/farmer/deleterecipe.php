
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_recipe where id=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:viewrecipe.php');

?>