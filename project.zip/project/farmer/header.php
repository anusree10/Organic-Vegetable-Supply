<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE HTML><head>
<title>Organic Vegetable Supply</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/styleayur.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<link href="../css/style1.css" rel='stylesheet' type='text/css' media="all">
  <link href="../css/style2.css" type="text/css" rel="stylesheet" />
  <link href="style/style.css" rel="stylesheet" type="text/css">

<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script src="js1/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js1/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js1/nav.js"></script>
<script type="text/javascript" src="js1/move-top.js"></script>
<script type="text/javascript" src="js1/easing.js"></script>
<script type="text/javascript" src="js1/nav-hover.js"></script>
  <script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
 
<div class="header_top_right"><script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>

		 
		  <div class="currency" title="currency">
					
		    <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
   </div>
		   
		 <div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		 <li><a href="farmer_home.php">Home</a></li>
     
  
 <!--li><a href="#">Tips & Advice</a>
    <ul>
			    <li><a href="gg.php">Upload</a></li>
				 <li><a href="">View</a></li>
				 </ul>
            
  </li-->
 <li><a href="">gallery</a>
	<ul> 
	<li><a href="upload.php">Add pictures</a></li>
	<li><a href="viewpicture.php">View pictures</a></li>	
	</ul></li>
 
	<li><a href="">Recipe</a>
	<ul> 
	<li><a href="addrecipe.php">Add Recipe Name</a></li>
	<li><a href="viewrecipe.php">View Recipe list</a></li>	
	</ul></li>
	<li><a href="">Products</a>
	<ul> 
	<li><a href="productadd.php">Add Products</a></li>
	<li><a href="productview.php">View Products</a></li>	
	</ul></li>
	
  <li><a href="suggestion.php">Chat</a></li>
  
  <li><a href="myprofile.php">Profile</a></li>
  <li><a href="logout.php">Logout</a></li>
  
  

  <div class="clear"></div>
</ul>
</div>

	<div class="header_bottom">
	
		<div class="header_bottom_left">
		<br><br>
 <center><font size="+2" style="background-color:#FF9900" color="#FFFFFF">
 <?php
		 if(isset ($_SESSION['email']))
		 {
		 echo "Welcome: ".$_SESSION['email'];
		 }
		
?>

</font></center>		
				
	  </div>
			<div class="section group">
							
				
			</div>
		  <div class="clear"></div>
	</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
</div>

</div>
</div>

    </div>
   
							  
</html>

