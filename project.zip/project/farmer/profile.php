
<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>

<?php 
extract($_REQUEST);
$id;
?>
<form id="f1" method="post" enctype="multipart/form-data" action="updateprofile.php">
<?php
$qry="select * from users,tbl_district,tbl_city where users.district=tbl_district.distid and users.city=tbl_city.cityid and users.id='$uid'";

  $res=setData($qry);
  while($row1=mysqli_fetch_array($res))
  {


$fname=$row1['first_name'];
$lname=$row1['last_name'];	
$email=$row1['email'];
$district=$row1['district'];
$city=$row1['city'];	
$phone=$row1['phone'];
$street=$row1['street'];
$image=$row1['image'];

?>
<link href="css1/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css1/style.css" rel='stylesheet' type='text/css' />

<!-- Graph CSS -->
<link href="css1/font-awesome.css" rel="stylesheet">

<!-- jQuery -->


<script>
    function dist()
    {
        var district=document.getElementById('district').value;
       
        var data=new FormData();
        data.append('did',district);

        $.ajax({
            method:'post',
            url:"districtaction.php",
            processData: false,
            contentType:false,
            data: data,
            success:function(result){
            // alert(result);
             var r=JSON.parse(result);
             $('#city').html("<option value=0>"+"select City"+"</option>");

             for(i=0;i<r.length;i++){
             $('#city').append("<option value="+r[i].id+">"+r[i].value+"</option")
             }
            }
        })

    }
</script>

 
	
	<div class="container" style="background-color:#00CC66; width:1350px; height:1000px">
	<center>
<h2><font color="#000000">Edit your Profile</font></h2>
<br><br>
<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/oh-autoval-style.css">
	<script src="../js/jquery.min.js"></script>
	<script src="../js/oh-autoval-script.js"></script>
    <div class="regisFrm">
		<form onSubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
		<input type="file" name="image" id="image" class="av-image" av-message="Image validation">
			<img src="../images/<?php echo $image;?>" style="width:200px; height:200px;" />
    <input type="hidden" name="hid_image" value="<?php echo $image ?>" required />
			<br>
		<label style="display:inline-block"><span class="username"><font color="#000000">First Name:</font></span></label>
		<input type="text" name="first_name" id="first_name" value="<?php echo $fname; ?>" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="FIRST NAME" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display:inline-block;width: 30%;"  required=""><br>
		
			
			<div class="username">
				<label><span class="username"><font color="#000000">Last Name:</font></span></label>
				 <input type="text" name="last_name" id="last_name" value="<?php echo $lname; ?>" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="LAST NAME"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 30%;"  required="">
				<div class="clearfix"></div>
			</div>
			<div class="username">
				<label><span><font color="#000000">Email:<font color="#00CC66">vvvv</font></font></span></label>
				<input type="email" class="av-email" value="<?php echo $email; ?>" av-message="enter valid email" name="email" id="email" placeholder="EMAIL" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 30%;"  required="" />
				<div class="clearfix"></div>
			</div>
			<div class="username">
				<label><span class="username"><font color="#000000">District:<font color="#00CC66">vv</font></font></span></label>
				<select name="district" id="district" class="name"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;color:#000000;width: 30%;"  required="" onChange="return dist()">
        <option value="0">---Select---</option>
        <?php
	$qry="select * from tbl_district";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>" <?php if($district==$row[0]){    ?> selected="selected" <?php } ?>><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
				
				<div class="clearfix"></div>
			</div>
			<br>
			<div class="username">
				<label><span class="username"><font color="#000000">City:<font color="#00CC66">vvvv.</font></font></span></label>
				
	   <select name="city" id="city" style="outline: none; padding: 10px 10px 10px 10px;font-size: 14px;color:#000000;display: inline-block;width: 30%;"  required="" onChange="getSub(this.value)">
	   <option value="0">---Select---</option>
        <?php
		//$cid=$_POST['did'];
	$qry="SELECT * FROM tbl_city WHERE cityid='$city' ";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
	 <option value="<?php echo $row[0];?>" <?php if($city==$row[0]){    ?> selected="selected" <?php } ?>><?php echo $row[2];?></option>
	<?php
	}
	?>
                   
					
                    </select>    
					<br>
		
				<div class="clearfix"></div>
			</div>
			<div class="username">
				<label><span class="username"><font color="#000000">Street:<font color="#00CC66">vv</font></font></span></label>
				<input type="text" name="street" id="street"  value="<?php echo $street; ?>" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="LAST NAME"  style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 30%;"  required="">
				
				<div class="clearfix"></div>
			</div>
			<br>
				
			<div class="username">
				<label><span class="username"><font color="#000000">Phone:<font color="#00CC66">vv</font></font></span></label>
				<input type="text" name="phone" id="phone"  value="<?php echo $phone; ?>" class="av-phone" av-message="Enter valid phone number" placeholder="PHONE NUMBER" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: inline-block;width: 30%;"  required="">
				
				<div class="clearfix"></div>
			</div>
			<br>
			<div class="send-button">
			<input type="hidden" value="<?php echo $uid?>" name="id" />
                <center><input  type="submit" name="submit" value="UPDATE YOUR ACCOUNT" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 20px;display: block;width: 30%;">
            </div>
			<div class="clearfix"></div>
			<br>
			<?php }?>
		</form>
		
				
	</div>
	</div>
	</div>
</body>
</html>