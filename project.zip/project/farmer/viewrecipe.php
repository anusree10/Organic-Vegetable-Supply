<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<?php
if(isset($_GET['error']))
{
   $text=$_GET['error'];

  ?>
  <font size="+2">
  <div onclick="this.style.display='none';" style="padding:20px;background-color:#66CCFF;color:#000000">
  <strong><?php echo $text; ?></strong>
  <input  type="submit" name="submit" value="OK" />
  
  </div>
  </font>
  <?php
  
}
?>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC66;
}
</style>
<link rel="stylesheet" href="css/table-style.css">  
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2>Recipes</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							<th>Recipe Name</th>
							<th>Description</th>
							<th>Image</th>
							<th>Operations</th>
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_recipe";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row[1];?>&nbsp;</td>
	<td width="350px"><?php echo $row[3];?> &nbsp;</td>
	 <td><img src="images/<?php echo $row['rec_img_name'];?>"width="100px" height="100px" />&nbsp;</td>
	   <td><span class="style2 style1">
     <a href="editrecipe.php?id=<?php echo $row[0];?>"><input type="submit" name="edit" value="EDIT" /></a> &nbsp;
	
	  <a href="deleterecipe.php?id=<?php echo $row[0];?>"><input type="submit" name="delete" value="DELETE" /></a>
      &nbsp;</span></td>
	
	  
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						</div>
						</div>
						</div>
						