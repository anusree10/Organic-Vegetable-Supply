<?php
$con=mysqli_connect("localhost","root","","store");

if(isset($_POST['submit']))
{

$uid=$_REQUEST['uid'];
$y=$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],"images/".$y);
