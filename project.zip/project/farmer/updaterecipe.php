<?php
include 'query.php';
extract($_REQUEST);
extract($_POST);
	$fname=$_FILES['image']['name'];
	$id=$_POST['id'];
	if(file_exists($fname))
	{
		$t=date('His');
		$fname=$t.$fname;
		
	}
	
	
	
	
	if(isset($fname))
 {
$image=$fname;
 }
 else
  {
	$image=$hid_image;
  }
	
	
	if(file_exists($_FILES['image']['tmp_name']))
	
	{
	
	move_uploaded_file($_FILES['image']['tmp_name'],"images/".$fname);
	 $qry="update tbl_recipe set rec_title='$name',rec_desc='$descr',rec_img_name='$image' where id='$id' ";
}
else
{
 $qry="update tbl_recipe set rec_title='$name',rec_desc='$descr' where id='$id' ";
}
	
	
	

$res=setData($qry);
  
 if($res)
   {
   header("location:viewrecipe.php?error=Your recipe is updated...");
   //echo "<script>window.onload=function(){alert('Your account is updated....!');window.location='profile.php';}</script>";


   }


