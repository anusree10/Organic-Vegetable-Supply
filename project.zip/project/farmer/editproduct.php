<?php
include '../config.php';
CheckLogout();
?> 
<?php
include 'header.php';
?>
<?php 
extract($_REQUEST);
$id;
?>
<form id="f1" method="post" enctype="multipart/form-data" action="updateproduct.php">
<?php 

$qry="select * from products,tbl_category where products.catid=tbl_category.catid and products.id='$id' ";
//$qry="select * from tbl_product,tbl_category where tbl_product.catid=tbl_category.catid and tbl_product.productid='$catid' ";
  $res=setData($qry);
  while($row1=mysqli_fetch_array($res))
  {

$catid=$row1['catid'];
$qty=$row1['quantity'];	
$name=$row1['product_name'];
$descr=$row1['product_desc'];
$image=$row1['product_img_name'];	
$price=$row1['price'];


?>

<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#66CC66;
}
</style>			
					<div class="clearfix"></div>
				</div>
	
<div class="container">
<h2><center>Edit products</center></h2>
    
<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
	 <form onsubmit="return" class="oh-autoval-form" method="post" enctype="multipart/form-data">
      <select name="cat" id="cat" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: block;width: 95%;"  required="" onChange="getSub(this.value)">
        <option value="0">---Select---</option>
        <?php
	$qry="select * from tbl_category";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>" <?php if($catid==$row[0]){    ?> selected="selected" <?php } ?>><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
		<br>
		
            <input type="text" name="qty" value="<?php echo $qty; ?>" id="code"    required>
			<br>
            
            <input type="text" name="name" value="<?php echo $name; ?>" id="name" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="PRODUCT NAME"  required>
			<br>
			<input type="text" class="av-name" av-message="Please eneter valid description" name="descr" id="descr" value="<?php echo $descr;?>" placeholder="PRODUCT DESCRIPTION" required>
			 <br>
			
			<input type="text" name="price" id="price"  value="<?php echo $price?>" class="av-price" av-message="Enter floating point with maximum 2 digits (0.99)" placeholder="PRICE" required>
			<br>
			
			
			<input type="file" name="image" id="image" class="av-image" av-message="Image validation">
			<img src="../images/<?php echo $image;?>" width="100px" height="100px" />
    <input type="hidden" name="hid_image" value="<?php echo $image ?>" required />
			<br>
			<div class="send-button">
			<input type="hidden" value="<?php echo $id?>" name="id" />
                <center><input  type="submit" name="submit" value="UPDATE PRODUCT">
            </div>
<?php }?>
</form>
         
  
 
  
  