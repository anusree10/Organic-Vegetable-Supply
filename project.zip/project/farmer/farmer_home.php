
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
include '../config.php';


CheckLogout();




?> 
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Farmer</title>

	<!--meta tags -->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Blissful Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); }
	</script>
	<!--//meta tags ends here-->

	<!--booststrap-->
	
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
	<!--//booststrap end-->
	
	<!-- font-awesome icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- //font-awesome icons -->
	
	<!-- banner text slider-->

	<!--// banner text slider-->
	
	<!--jquery-css counter time-->
		<link rel="stylesheet" href="css/jquery.countdown.css" />
	<!--//jquery-css counter time-->
	
	<!--lightbox slider-->
    <link rel="stylesheet" href="css/lightbox.css">  
   <!-- lightbox slider-->

	<!--stylesheets-->
	<link href="css/style.css" rel='stylesheet' type='text/css' media="all">
	<!--//stylesheets-->
	<link href="//fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">

</head>

<body>
<div class="banner">

<div class="header-w3layouts"> 
		<!-- Navigation -->
	
		
	
			
			<!-- Collect the nav links, forms, and other content for toggling -->
			<?php
			include 'header.php';
			?>
		
	</div>

	<div class="clearfix"> </div>

	</div>
	
  </div>
<div class="container">

		<!--Slider-->
		<div class="slider">
			<div class="callbacks_container w3l">
				<ul class="rslides" id="slider">
					<li>
					
						<div class="slider-info">
							<h4>Happy Life For Ever</h4>
						    <p>Move To Traditional</p>
							
						</div>
					</li>
					<li>
						
						<div class="slider-info">
							<h4>To Get a Best Health In Our Lives </h4>
							<p>Moves to Organic</p>
						</div>
					</li>
				</ul>
				
			</div>
			<div class="clearfix"></div>
			
</div>

  </div>
</div>
<!--//banner-->
			<!--about-->
		<div class="about" id="about">
	<div class="container">
		<h3 class="title">About</h3>
		<div class="about-top-grids">
				<div class="col-md-8 about-top-grid">
					<h4>Organic
					</h4>
					<p>Ayurveda is a 5,000-year-old system of natural healing that has its origins in the Vedic culture of India. Although suppressed during years of foreign occupation, Ayurveda has been enjoying a major resurgence in both its native land and throughout the world. Tibetan medicine and Traditional Chinese Medicine both have their roots in Ayurveda. Early Greek medicine also embraced many concepts originally described in the classical Ayurvedic medical texts dating back several thousands of years.

More than a mere system of treating illness, Ayurveda is a science of life (Ayur = life, Veda = science or knowledge). It offers a body of wisdom designed to help people stay vital while realizing their full human potential. Providing guidelines on ideal daily and seasonal routines, diet, behavior and the proper use of our senses, Ayurveda reminds us that health is the balanced and dynamic integration between our environment, body, mind, and spirit.
			         
					</p>
					<div class="bar-grids">
				<h6>Health<span> 100% </span></h6>
				<div class="progress">
					<div class="progress-bar progress-bar-striped active" style="width: 100%">
					</div>
				</div>
				<div class="mid-bar">
					<h6>Results<span> 85% </span></h6>
					<div class="progress">
						<div class="progress-bar progress-bar-striped active" style="width: 85%">
						</div>
					</div>
				</div>
				<h6>After Effects<span>1% </span></h6>
				<div class="progress">
					<div class="progress-bar progress-bar-striped active" style="width: 1%">
					</div>
				</div>
			</div>
				</div>
				<div class="col-md-4 about-top-image" >
				</div>
				<div class="clearfix"> </div>
	  </div>
</div>
</div>
	<!--//about-->
	
	<!--login-->
				
<!--//login-->
	<!--Services-->
	<!--div class="services" id="services">
		<div class="container">
			<h3 class="title clr">Services</h3>
		
				<div class="banner-bottom-girds text-center">
					<div class="col-md-6  col-sm-6 col-xs-6  its-banner-grid">
					<div class="white-shadow">
						<span class="fa fa-truck banner-icon" aria-hidden="true"></span>
						<h4>Advice</h4>
						<p>To advice better treatements</p>
					</div>
					</div>
					<div class="col-md-6  col-sm-6 col-xs-6 its-banner-grid">
					<div class="white-shadow">
						<span class="fa fa-picture-o banner-icon" aria-hidden="true"></span>
						<h4>To Get Better Products</h4>
						<p>Getting better products to customers</p>
					</div>
					</div>
					<div class="col-md-6 col-sm-6 col-xs-6  its-banner-grid">
					<div class="white-shadow">
						<span class="fa fa-health banner-icon" aria-hidden="true"></span>
						<h4>Consultation</h4>
						<p>consulting patients </p>
					</div>
					</div>
					<div class="col-md-6  col-sm-6 col-xs-6  clr1 its-banner-grid">
					<div class="white-shadow">
						<span class="fa  fa-heart  banner-icon" aria-hidden="true"></span>
						<h4>Hospitals</h4>
						<p> Finding better Hospitals</p>
					</div>
					</div>
					<div class="clearfix"> </div>
				</div>
		</div>
	</div>
	
	<!--//Services-->
	
  
	
	

		<!--slider sectionimages-->
	
    <!--div class=" slider-photo">
	<div class="container">
	<h3 class="title clr">Our Products</h3>
		<div class="col-md-12 couple">
                <div id="Carousel" class="carousel slide">
                 
                <ol class="carousel-indicators">
                    <li data-target="#Carousel" data-slide-to="0" class="active"></li>
                    <li data-target="#Carousel" data-slide-to="1"></li>
                    <li data-target="#Carousel" data-slide-to="2"></li>
                </ol>
                 
                <!-- Carousel items -->
             <!--div class="carousel-inner">
                    
                <div class="item active">
                	<div class="row">
                	  <div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i1.jpg" alt="Image" style="max-width:100%;"></div></div>
                	  <div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i2.jpg" alt="Image" style="max-width:100%;"></div></div>
                	  <div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i3.jpg" alt="Image" style="max-width:100%;"></div></div>
                	  <div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i4.jpg" alt="Image" style="max-width:100%;"></div></div>
                	</div><!--.row-->
                </div><!--.item-->
                 <!--div class="clearfix"> </div>
                <div class="item">
                	<div class="row">
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i2.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering "><div class="thumbnail"><img src="images/i1.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i4.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i3.jpg" alt="Image" style="max-width:100%;"></div></div>
                	</div><!--.row-->
                </div><!--.item-->
                <!--div class="clearfix"> </div>
                <div class="item">
                	<div class="row">
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i4.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i2.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i1.jpg" alt="Image" style="max-width:100%;"></div></div>
                		<div class="col-md-3 col-sm-3 col-xs-3 slidering"><div class="thumbnail"><img src="images/i3.jpg" alt="Image" style="max-width:100%;"></div></div>
                	</div><!--.row-->
                </div><!--.item-->
                 <!--div class="clearfix"> </div>
                </div><!--.carousel-inner-->
                  <a data-slide="prev" href="#Carousel" class="left carousel-control">‹</a>
                  <a data-slide="next" href="#Carousel" class="right carousel-control">›</a>
                </div><!--.Carousel-->
                 
		</div>
		<!--div class="clearfix"> </div>
	  </div>
	</div>
<!--//container-->
		<!--//slider sectionimages-->
<!-- gallery -->

		<!--div id="gallery" class="gallery"> 
		<h3 class="title">Gallery</h3> 
		<div class="gallery-w3lsrow">
			<div class="col-sm-3 col-xs-6 gallery-grids">
				<div class="w3ls-hover">
					<a href="images/g1.jpg" data-lightbox="example-set" data-title=" Ayurveda is a science of life, the body is simultaneously matter field and energy field">
						<img src="images/a7.jpg" class="img-responsive zoom-img" alt="">
						<div class="view-caption">
							<h5>Vedha</h5>
						
						</div>
					</a>
				</div>
			</div>
			<div class="col-sm-3 col-xs-6 gallery-grids">
				<div class="w3ls-hover">
					<a href="images/a4.jpg" data-lightbox="example-set" data-title=" Ayurveda is a science of life, the body is simultaneously matter field and energy field">
						<img src="images/a4.jpg" class="img-responsive zoom-img" alt="">
						<div class="view-caption">
							<h5>Vedha</h5>
						
						</div>
					</a>
				</div>
			</div>
			<div class="col-sm-3 col-xs-6 gallery-grids">
				<div class="w3ls-hover">
					<a href="images/i3.jpg" data-lightbox="example-set" data-title=" Ayurveda is a science of life, the body is simultaneously matter field and energy field">
						<img src="images/i3.jpg" class="img-responsive zoom-img" alt="">
						<div class="view-caption">
							<h5>Vedha</h5>
						
						</div>
					</a>
				</div>
			</div>
			<div class="col-sm-3 col-xs-6 gallery-grids">
				<div class="w3ls-hover">
					<a href="images/i4.jpg" data-lightbox="example-set" data-title=" Ayurveda is a science of life, the body is simultaneously matter field and energy field">
						<img src="images/i4.jpg" class="img-responsive zoom-img" alt="">
						<div class="view-caption">
							<h5>Vedha</h5>
							
						</div>
					</a>
				</div>
			</div>
			 
			<div class="clearfix"> </div> 
		</div>

	</div>
		<!-- //gallery -->
	<!--contact-->
		

	

		

		
				<!--footer-->
				<!--div class="buttom-w3">
				<div class="container">
				<div class=" bottom-head text-center">
		  <h2><a href="index.html">PANCHAKARMA</a></h2>
		  <div class="buttom-para">
		  <p>The body is simultaneously matter field and energy field</p>
		  <p>Ayurveda is a science of life</p>
		  </div>
		</div>
<div class=" text-center">
			   <div class="post">
            <form action="newuserregprocess.php" method="post">
			  
			         <div class="letter">
					<input class="email" type="email" placeholder="Your email..." required>
					</div>
					<div class="newsletter">
					<input type="submit" value="Subscribe">
					</div>
				</form>
</div>
          </div>
				</div>
				<div class=" copyright text-center">
			    			<div class="icons">
							<ul>
								
							</ul>
						</div>

			</div>
				</div>
				
				<footer>
				<p>  &copy; 2018 Ayurvedha. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"> Anusree </a></p>
	</footer>


	<!--js working-->
	<script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>
	<script src="js/bootstrap.js"></script>
	<!-- //js  working-->

			<!--  light box js -->
		<script src="js/lightbox-plus-jquery.min.js"> </script> 
		<!-- //light box js--> 
		<!-- banner-->
<script src="js/responsiveslides.min.js"></script>
		<script>
				$(function () {
					$("#slider").responsiveSlides({
						auto: true,
						pager: true,
						nav: true,
						speed: 1000,
						namespace: "callbacks",
						before: function () {
							$('.events').append("<li>before event fired.</li>");
						},
						after: function () {
							$('.events').append("<li>after event fired.</li>");
						}
					});
				});
			</script>
<!--// banner-->
	<!--scripts-->
	<script src="js/jquery.countdown.js"></script>
	<!--countdowntimer-js-->
	<script src="js/script.js"></script>
	<!--countdowntimer-js-->
	<!--//scripts-->
	
	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 900);
			});
		});
	</script>
	<!-- start-smoth-scrolling -->
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function () {

			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
			};


			$().UItoTop({
				easingType: 'easeOutQuart'
			});

		});
	</script>
	<!-- //here ends scrolling icon -->
	
</body>

</html>