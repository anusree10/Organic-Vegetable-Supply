<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>

<br><br>
<h2><center><font color="#993300">Add Recipe</font></h2>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC66;
}
</style>
<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
        <form onsubmit="return" class="oh-autoval-form" method="post"  enctype="multipart/form-data" >
		<center>
		 <input type="text" name="name" id="name" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="RECIPE NAME"  required style="width:30%; height:30%; ">
			<br>
            
			<input type="file" name="image" id="image" class="av-image" av-message="Image validation" style="width:30%; height:30%;" >
			<br>
            <input type="text" class="av-name" av-message="Please eneter valid description" name="descr" id="descr" placeholder="RECIPE DESCRIPTION" required style="width:30%; height:30%; ">
			 <br></center>
             <div class="send-button">
                <center><input  type="submit" name="submit" value="ADD RECIPE" style="width:32%; height:30%;" ></center>

            </div>
			
</form>


<?php
$con=mysqli_connect("localhost","root","","store");

if(isset($_POST['submit']))
{

$name=$_POST['name'];
$y=$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],"images/".$y);
$descr=$_POST['descr'];



$qry="insert into tbl_recipe(rec_title,rec_img_name,rec_desc) values('$name','$y','$descr')";
$res=mysqli_query($con,$qry);
echo "<script>window.onload=function(){alert('Recipe added....!');window.location='addrecipe.php';}</script>";
}
?>