<?php
session_start();
//include '../query.php';
$fid=$_SESSION['id'];

include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<?php 
extract($_REQUEST);
$uid;
?>
<br><br>

<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#009999;
}
input.form-control {
    background: #fff;
    border: none;
    padding: 12px 15px;
    letter-spacing: 1px;
    font-size: 15px;
}
</style>

<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
	<h2><center><font color="#993300">Reply to User</font></h2>
	<?php
  
   
		  $con=mysqli_connect("localhost","root","","store");
		  $qry="select * from users where id='$fid'";
		   $res=setData($qry);
		  while($row=mysqli_fetch_array($res))
		  {
		 
$email=$row['email'];
$qry="select * from users where id='$uid'";
		   $res=setData($qry);
		  while($row=mysqli_fetch_array($res))
		  {
		 
$uemail=$row['email'];
		  ?>
		  
<form action=""  onsubmit="return" class="oh-autoval-form" method="post">
     <center><label for="fname">Send from</label>
   
		 <input type="text" name="name" id="name"  value="<?php echo $email;?>"  required style="width:30%; height:30%; " disabled="disabled">
			<br>

    <label for="lname">Send to</label>
     &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="name" id="name"  value="<?php echo $uemail;?>"    required style="width:30%; height:30%; " disabled="disabled">
	 <br>
	 
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea class="form-control av-name" type="text" name="reply"  av-message="Please enter your reply" placeholder="Please write your reply....." required="" style="height:150px; width:32%" ></textarea>
							
						<br><br>
						<div>
							<font size="+1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;<input  type="submit" name="submit" value="SEND" style="background-color:#006699; width:30%; height:40%"></font>
	</form>
	<?php
	}
	}
	?>
	<?php
$con=mysqli_connect("localhost","root","","store");

if(isset($_POST['submit']))
{

$reply=$_POST['reply'];

$qry="insert into tbl_reply(user_id,farmer_id,reply,status) values('$uid','$fid','$reply',1)";
$res=mysqli_query($con,$qry);
echo "<script>window.onload=function(){alert('Sending your reply to the farmer. Thank youuu....!');window.location='suggestion.php';}</script>";
}
?>

 
