<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<?php 
extract($_REQUEST);
$id;
?>
<form id="f1" method="post" enctype="multipart/form-data" action="updaterecipe.php">
<?php 

$qry="select * from tbl_recipe where id='$id' ";
//$qry="select * from tbl_product,tbl_category where tbl_product.catid=tbl_category.catid and tbl_product.productid='$catid' ";
  $res=setData($qry);
  while($row1=mysqli_fetch_array($res))
  {

	
$name=$row1['rec_title'];
$image=$row1['rec_img_name'];
$descr=$row1['rec_desc'];
	



?>
<br><br>
<h2><center><font color="#993300">Edit Recipe</font></center></h2>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC66;
}
</style>
<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
        <form onsubmit="return" class="oh-autoval-form" method="post" >
		<center>
		
			<center><img src="../image/<?php echo $image;?>" width="100px" height="100px" /></center>
			<input type="file" name="image" id="image" class="av-image" av-message="Image validation" style="width:30%; height:30%;" >
    <input type="hidden" name="hid_image" value="<?php echo $image ?>" required />
			<br>
		 <input type="text" name="name" id="name" value="<?php echo $name; ?>" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="RECIPE NAME"  required style="width:30%; height:30%; ">
			<br>
            
			
            <input type="text" class="av-name" av-message="Please eneter valid description"  value="<?php echo $descr; ?>" name="descr" id="descr" placeholder="RECIPE DESCRIPTION" required style="width:30%; height:30%; ">
			 <br></center>
             <div class="send-button">
			 <input type="hidden" value="<?php echo $id?>" name="id" />
                <center><input  type="submit" name="submit" value="EDIT RECIPE" style="width:32%; height:30%;" >
            </div>
			<?php }?>
</form>