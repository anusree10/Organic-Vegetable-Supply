<?php
session_start();
//include '../query.php';
$fid=$_SESSION['id'];
$con=mysqli_connect("localhost","root","","store");

if(isset($_POST['submit']))
{
$cat=$_POST['cat'];
$qty=$_POST['qty'];
$name=$_POST['name'];
$descr=$_POST['descr'];

$y=$_FILES['image']['name'];

move_uploaded_file($_FILES['image']['tmp_name'],"images/".$y);
$price=$_POST['price'];

$qry="insert into products(catid,farid,quantity,product_name,product_desc,product_img_name,price) values('$cat','$fid','$qty','$name','$descr','$y','$price')";
$res=mysqli_query($con,$qry);
echo "<script>window.onload=function(){alert('Product added....!');window.location='productadd.php';}</script>";
}

?>


<?php

include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<div class="container">
<h2><center>Add products</center></h2>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#66CC66;
}
</style>    
<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
        <form onsubmit="return" class="oh-autoval-form" enctype="multipart/form-data" method="post" >
		<select id="cat" name="cat" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;display: block;width: 99%;"  required="" onchange="return dist()" required>
                    <option value="0">----Category----</option>
                    <?php 
                    $con=mysqli_connect("localhost","root","","store");
                    $sql="SELECT * FROM tbl_category";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['catid'];
                        $name=$row['category'];
                        ?>
                        
                        <option value='<?php echo $id ?>'><?php echo $name ?></option>";
                        <?php
                    }
                    ?>
                    </select>
                    
             
					 <br>
					  <input type="text" name="qty" id="qty"  placeholder="QUANTITY"  required>
			<br>
            
            <input type="text" name="name" id="name" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="PRODUCT NAME"  required>
			<br>
            
			
            <input type="text" class="av-name" av-message="Please eneter valid description" name="descr" id="descr" placeholder="PRODUCT DESCRIPTION" required>
			 <br>
             
			<!--input type="text" name="district" placeholder="DISTRICT" required>
			<input type="text" name="city" placeholder="CITY" required-->
			
            
			
			
			<input type="file" name="image" id="image" class="av-image" av-message="Image validation">
			<br>
			<input type="text" name="price" id="price"  class="av-price" av-message="Enter floating point with maximum 2 digits (0.99)" placeholder="PRICE" required>
			
			
			<br>
            <div class="send-button">
                <center><input  type="submit" name="submit" value="ADD PRODUCT">
            </div>
</form>


 
				 
	
	
							</tbody>
						</table>
					</div>
			</div>
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->

		