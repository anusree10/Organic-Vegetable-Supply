<?php
include '../query.php';
extract($_REQUEST);
extract($_POST);
	$fname=$_FILES['image']['name'];
	$id=$_POST['id'];
	if(file_exists($fname))
	{
		$t=date('His');
		$fname=$t.$fname;
		
	}
	
	
	
	
	if(isset($fname))
 {
$image=$fname;
 }
 else
  {
	$image=$hid_image;
  }
	
	
	if(file_exists($_FILES['image']['tmp_name']))
	
	{
	
	move_uploaded_file($_FILES['image']['tmp_name'],"images/".$fname);
	 $qry="update products set catid='$cat',quantity='$qty',product_name='$name',product_desc='$descr',product_img_name='$image',price='$price' where id='$id' ";
}
else
{
 $qry="update products set catid='$cat',quantity='$qty',product_name='$name',product_desc='$descr',price='$price' where id='$id' ";
}
	
	
	

$res=setData($qry);
  
  if($res)
   {
header('location:productview.php');

   }



