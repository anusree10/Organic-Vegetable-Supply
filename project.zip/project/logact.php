<?php
session_start();
$con=mysqli_connect("localhost","root","","store"); //database connection page

if(isset($_POST["loginSubmit"]))
{
$username=$_POST["email"];   
	$pwd=md5($_POST['password']);
	
	$sql="select * from users where email='$username' and password ='$pwd'"; 
	//value querried from the table
	//echo $sql;
	$res=mysqli_query($con,$sql);
	
if($fetch = mysqli_fetch_array($res));
	{
	
	$status=$fetch['status'];
	$role=$fetch['role'];	
	if($username==$username && $pwd==$pwd && $role=="0")
		{
		session_start();
			///$_SESSION["name"]=$fetch['name'];
			$_SESSION["id"]=$fetch['id'];
			$_SESSION["email"]=$username;	// setting username as session variable 
			header("location:admin/admin_home.php");
		}
		elseif($username==$username && $pwd==$pwd && $status=="1" && $role=="1")
		{
		$_SESSION["email"]=$username;	// setting username as session variable 
		$_SESSION["id"]=$fetch['id'];
	    header("location:farmer/farmer_home.php");
	    }
		elseif($username==$username && $pwd==$pwd && $status=="1" && $role=="2")
		{
		$_SESSION["email"]=$username;	// setting username as session variable 
		$_SESSION["id"]=$fetch['id'];
	    header("location:customers/user_home.php");
		
	}
	else {
	header("location:index.php?error=Username or Password is incorrect OR your account is blocked.");
	 }
	 //else {
  //$message = "Username or Password is incorrect OR your account is blocked.\\nTry again.";
  //echo "<script type='text/javascript'>alert('$message');window.location='index.php';<!/script>";}
	
  
}
}
?>	
			