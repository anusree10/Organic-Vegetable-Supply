<?php session_start();

		//$_SESSION=array();		//session_destroy();
						
		//header("location:index.php");
	
session_destroy();
header("location:../project/index.php");					
?>

<!--?php 
session_start();
session_destroy();
header("location:../../project/home.php");
?-->


<!--?php
//start session
session_start();
//load and initialize user class
include 'user.php';
$user = new User();
if(!empty($_REQUEST['logoutSubmit'])){
    //remove session data
    unset($_SESSION['sessData']);
    session_destroy();
    //store logout status into the ession
    $sessData['status']['type'] = 'success';
    $sessData['status']['msg'] = 'You have logout successfully from your account.';
    $_SESSION['sessData'] = $sessData;
    //redirect to the home page
    header("Location:index.php");
}else{
    //redirect to the home page
    header("Location:index.php");
}
?>
<!--?php 
include 'config.php';


	unset($_SESSION["id"]);

session_destroy();
header("location:../index.php");
?--> 






<!--?php
//start session
session_start();
//load and initialize user class
session_destroy();
    //redirect to the home page
    header("Location:index.php");

?-->
