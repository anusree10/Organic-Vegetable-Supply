-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2019 at 07:24 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `product_code` varchar(60) NOT NULL,
  `product_name` varchar(60) NOT NULL,
  `product_qty` varchar(50) NOT NULL,
  `product_desc` text NOT NULL,
  `product_img_name` varchar(60) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `catid`, `product_code`, `product_name`, `product_qty`, `product_desc`, `product_img_name`, `price`) VALUES
(1, 3, 'PD1001', 'Apple', '', 'It is a type of fruit. It is very tasty and yummi', 'about.jpg', '80.00'),
(2, 1, 'PD1002', 'Carrot', '', 'It is a type of vegetable. It is a tasty veg item', 'd2.jpg', '60.00'),
(3, 2, 'PD1003', 'Mustard', '', 'It is a type of spices and is used for making curry', 'v4.jpg', '50.00'),
(4, 4, 'PD1004', 'Orange Juice', '', 'It is a type of Juice. Very tasty and healthy juice ', 'd6.jpg', '60.20'),
(5, 1, 'PD1005', 'Pappaya', '', 'It is a type of vegetable and also afruit', 'bg.jpg', '42.50'),
(6, 3, 'PD1006', 'Grapes', '', 'It is a type of fruit. Used for making tasty juice', 'd3.jpg', '25.00'),
(7, 1, 'PD1007', 'Pumpkin', '', 'It is a type of vegetable and used for making curry', 'g3.jpg', '45.00'),
(8, 1, 'PD1008', 'Carrot Juice', '', 'It is a type of juice it is very taty and healthy', '1.jpg', '200.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cart`
--

INSERT INTO `tbl_cart` (`id`, `user_id`, `product_id`, `quantity`, `date`) VALUES
(4, 3, 8, 1, '2019-04-29'),
(5, 3, 7, 1, '2019-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catid` int(11) NOT NULL,
  `category` varchar(60) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catid`, `category`, `status`) VALUES
(1, 'Vegetables', 0),
(2, 'Spices', 0),
(3, 'Fruits', 0),
(4, 'Juices', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE `tbl_city` (
  `cityid` int(11) NOT NULL,
  `distid` int(11) NOT NULL,
  `cname` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`cityid`, `distid`, `cname`) VALUES
(1, 4, 'Allappy'),
(2, 5, 'Kanjirappally'),
(3, 5, 'Manimala'),
(4, 6, 'Kattappana'),
(5, 7, 'Palarivattam'),
(6, 5, 'Changanaseri'),
(8, 5, 'Ponkunnam'),
(10, 8, 'hgfh');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `con_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `far_id` int(11) NOT NULL,
  `text` varchar(250) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`con_id`, `user_id`, `far_id`, `text`, `status`) VALUES
(1, 3, 11, 'Plant more items', 1),
(2, 3, 2, 'You should plant potatos', 1),
(3, 3, 10, 'Your plantation is excellent', 1),
(4, 3, 4, 'Add more plants', 1),
(5, 5, 6, 'i think you have to add more pictures', 1),
(6, 5, 4, 'I like your plants ', 1),
(7, 8, 2, 'I like your products.', 1),
(8, 3, 4, 'I want to see your plantation directly..', 1),
(9, 3, 6, 'Which types of vegetables are produced more?', 1),
(10, 3, 9, 'I like your products very much..', 1),
(11, 3, 10, 'Can we see your plants directly?', 1),
(12, 3, 6, 'I like it', 1),
(13, 3, 2, 'I want to see your products directly', 1),
(14, 3, 2, 'What type of fertilization are used', 1),
(15, 3, 4, 'I like your products', 1),
(16, 3, 9, 'I want to see your plants', 1),
(17, 3, 6, 'good', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `distid` int(11) NOT NULL,
  `dname` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`distid`, `dname`) VALUES
(4, 'Alappuzha'),
(7, 'Ernakulam'),
(6, 'Idukki'),
(13, 'Kannur'),
(14, 'Kasargodu'),
(2, 'Kollam'),
(5, 'Kottayam'),
(11, 'Kozhikodu'),
(10, 'Malappuram'),
(9, 'Palakkadu'),
(3, 'Pathanamthitta'),
(8, 'Thrissur'),
(1, 'Trivandrum'),
(12, 'Vayanadu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fdbk`
--

CREATE TABLE `tbl_fdbk` (
  `fd_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fdbk`
--

INSERT INTO `tbl_fdbk` (`fd_id`, `user_id`, `text`, `date`, `status`) VALUES
(1, 3, 'I like this site..', '2019-04-29', 1),
(2, 5, 'This site is very helpful to me and thanks for this site...', '2019-04-29', 1),
(3, 8, 'This site is very useful for buying pure organic vegetables', '2019-04-29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `pay_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_name` varchar(100) NOT NULL,
  `card_no` varchar(200) NOT NULL,
  `exp_month` varchar(50) NOT NULL,
  `exp_year` varchar(50) NOT NULL,
  `cvv` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`pay_id`, `user_id`, `card_name`, `card_no`, `exp_month`, `exp_year`, `cvv`, `date`) VALUES
(1, 3, 'Rahul', '9865-7452-12542-6532', 'July', '2025', 332, '0000-00-00'),
(2, 3, 'Janu', '8596-4587-1254-5698', 'Auguest', '2025', 622, '2019-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `title` varchar(60) NOT NULL,
  `description` varchar(70) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `rate` varchar(50) NOT NULL,
  `image` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productid`, `catid`, `product_code`, `title`, `description`, `quantity`, `rate`, `image`) VALUES
(6, 1, 'PD1001', 'Tomato', 'Vegetable', '50', '60', 'org4.jpg'),
(7, 1, 'PD1002', 'Carrot', 'ikytyrytdfcghj', '50', '100', 'd2.jpg'),
(8, 2, 'PD1003', 'gsdv', 'hgvsdhvhgdc', '22', '50', '2.jpg'),
(9, 2, 'PD1004', 'gfd', 'gfdg', '52', '41', 'ab2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recipe`
--

CREATE TABLE `tbl_recipe` (
  `id` int(11) NOT NULL,
  `rec_title` varchar(100) NOT NULL,
  `rec_img_name` varchar(100) NOT NULL,
  `rec_desc` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_recipe`
--

INSERT INTO `tbl_recipe` (`id`, `rec_title`, `rec_img_name`, `rec_desc`) VALUES
(1, 'Aviyal', 'aviyal.jpg', 'Aviyal is a traditional kerala recipe made from mix vegetables, coconut and curd.'),
(4, 'Cherupauyar Thoran', 'cherupayar thoran.jpg', 'Thoran is a dry dish traditionally made of finely chopped vegetables such as cherupayar'),
(5, 'Cabbage Thoran', 'Cabbage-Thoran.jpg', 'Thoran is a dry dish traditionally made of finely chopped vegetables such as cabbage.'),
(6, 'Beetroot Curry', 'beeteoot.jpg', 'Beetroot curry  is a very simple preparation combined with onions, green chillies, grated beetroot etc'),
(7, 'Bitterguard curry', 'bitterguard.jpg', 'Wild bitter gourd, Momordica charantia, or bitter melon is a tropical vegetable native to Asia. Its very tasty'),
(8, 'Fried Potato', 'fried potato.jpg', 'Fried potatoes are a dish essentially consisting of potatoes which have been fried, or deep-fried, in hot cooking oil.'),
(9, 'Sambar', 'sambar.jpg', 'Sambaris a lentil-based vegetable stew or chowder, cooked with tamarind, and very tasty curry'),
(10, 'Vegetable Stew', 'vegetablestew.jpg', 'Vegetable stew is a combination of solid food ingredients that have been cooked in liquid.'),
(11, 'Coconut Thoran', 'coconut thoran.jpg', 'Thoran is a coconut-based vegetable dish in Kerala. This common dish is usually eaten with steamed rice. ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reply`
--

CREATE TABLE `tbl_reply` (
  `rply_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `con_id` int(11) NOT NULL,
  `reply` varchar(200) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reply`
--

INSERT INTO `tbl_reply` (`rply_id`, `user_id`, `farmer_id`, `con_id`, `reply`, `status`) VALUES
(1, 3, 2, 2, 'Ok I will try on next time', 1),
(2, 8, 2, 7, 'Thank you so much', 1),
(3, 3, 2, 13, 'Yes Please come', 1),
(4, 3, 2, 14, 'Jaiva valam', 1),
(5, 3, 9, 10, 'Thank you dear', 1),
(6, 3, 9, 16, 'Yes please come', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_upload`
--

CREATE TABLE `tbl_upload` (
  `id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `img_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_upload`
--

INSERT INTO `tbl_upload` (`id`, `farmer_id`, `img_name`) VALUES
(1, 2, 'images (1).jpg'),
(2, 2, 'download (10).jpg'),
(3, 2, 'download (7).jpg'),
(4, 2, 'images (11).jpg'),
(5, 2, 'images (9).jpg'),
(6, 2, 'images.jpg'),
(7, 2, 'download (9).jpg'),
(8, 2, 'images (16).jpg'),
(9, 2, 'download (8).jpg'),
(10, 4, 'download (4).jpg'),
(11, 4, 'download (6).jpg'),
(12, 4, 'f1.jpg'),
(13, 4, 'download (1).jpg'),
(14, 4, 'images.jpg'),
(15, 4, 'images (2).jpg'),
(16, 6, '1.jpg'),
(17, 6, 'raised-beds-various-vegetables-2x.jpg'),
(18, 6, '2.jpg'),
(19, 6, '3.jpg'),
(20, 6, '4.jpg'),
(21, 6, 'images (3).jpg'),
(22, 6, 'images (14).jpg'),
(23, 6, '5.jpg'),
(24, 6, '8.jpg'),
(25, 6, '7.jpg'),
(26, 6, '9.jpg'),
(27, 9, '12.jpg'),
(28, 9, 'images (4).jpg'),
(29, 9, '13.jpg'),
(30, 9, 'download (6).jpg'),
(31, 9, '8.jpg'),
(32, 9, '12.jpg'),
(33, 9, 'download.jpg'),
(34, 9, 'images (14).jpg'),
(35, 9, '15.jpg'),
(36, 9, 'download (8).jpg'),
(37, 9, 'images (4).jpg'),
(38, 10, '6.jpg'),
(39, 10, '10.jpg'),
(40, 10, '7.jpg'),
(41, 10, '16.jpg'),
(42, 10, '3.jpg'),
(43, 10, 'images (8).jpg'),
(44, 10, 'download (10).jpg'),
(45, 11, '10.jpg'),
(46, 11, 'download (1).jpg'),
(47, 11, '1.jpg'),
(48, 11, 'download (6).jpg'),
(49, 11, 'f1.jpg'),
(50, 11, '8.jpg'),
(51, 11, 'images (5).jpg'),
(52, 11, 'images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `street` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `forgot_pass_identity` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `role` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `district`, `city`, `street`, `password`, `phone`, `image`, `forgot_pass_identity`, `created`, `modified`, `status`, `role`) VALUES
(1, 'Admin', 'Admin', 'admin@gmail.com', '6', '4', '', '5168ec2991b2d49ce9124fc406e6dfa3', '8562421201', '', 'da0eeaa57c36dde72bf35da6683b3b5d', '2019-03-17 07:20:45', '2019-03-18 06:47:04', '1', '0'),
(2, 'Farmer', 'Farmer', 'farmer@gmail.com', '5', '3', 'abc 2nd street', 'dd0a92d3dea96175542d6da540065047', '9685741230', 'far5.jpg', NULL, '2019-03-17 07:21:56', '2019-03-17 07:21:56', '1', '1'),
(3, 'Aswathy', 'Dileep', 'user@gmail.com', '7', '5', 'melattuthakadi', 'c6092111c07e17c449fac138d5d2c333', '9582124260', 'user1.jpg', NULL, '2019-03-17 07:22:44', '2019-03-17 07:22:44', '1', '2'),
(4, 'Anu', 'Sree', 'anusree@gmail.com', '7', '5', 'Nachikolani', 'b231ae690888f868f4371d9acdd838f2', '9547896541', 'far10.jpg', NULL, '2019-03-18 07:16:34', '2019-03-18 07:16:34', '1', '1'),
(5, 'Akhila', 'Rajeev', 'anusreerajeev@mca.ajce.in', '5', '8', 'Vay 7th street', '6360de1d6252733edf755defd1948f50', '8921642653', '', 'b9f6a3a8afb4c862e4a37223c96999fa', '2019-03-18 08:06:55', '2019-04-03 12:33:42', '1', '2'),
(6, 'Veena', 'Sanal', 'anusreealackal@gmail.com', '7', '5', 'Mayavanm', '0bc1d2fe8ceb8d19b5c90a94f8b5165f', '8921642653', 'team3.jpg', '0edb67228607766a2f611193b31d3d8b', '2019-03-18 08:09:17', '2019-03-18 08:09:33', '1', '1'),
(7, 'Anupama', 'Parameswaran', 'Anu@gmail.com', '6', '4', 'Thulappally', 'c1d1dd5bda22d486a54583db89d454d4', '9685741230', '', NULL, '2019-04-09 07:28:06', '2019-04-09 07:28:06', '0', '2'),
(8, 'Mekha', 'Saji', 'mekha@gmail.com', '7', '5', 'Town centre', 'd4aa14dbdb849b4fdd36777c0ccca34d', '8475269531', '', NULL, '2019-04-09 16:17:18', '2019-04-09 16:17:18', '1', '2'),
(9, 'Gorilla', 'Lopez', 'gorilla@gmail.com', '4', '1', 'Edamaloor', '42a6f27deaca4e6e014b1a2ca83b1994', '8579325641', 'team2.jpg', NULL, '2019-04-12 17:00:03', '2019-04-12 17:00:03', '1', '1'),
(10, 'Subash', 'Sasi', 'subash@gmail.com', '6', '4', 'Thavalam', '04e6dc4e623e06a72071c232e94a1259', '9173201203', 'far2.jpg', NULL, '2019-04-13 08:52:52', '2019-04-13 08:52:52', '1', '1'),
(11, 'Raju', 'Rakhavan', 'raju@gmail.com', '7', '5', 'Thattekadu', '8240211a43bebe7c90af415b16a660f8', '8821302642', 'far7.jpg', NULL, '2019-04-13 11:15:40', '2019-04-13 11:15:40', '1', '1'),
(12, 'Abc', 'abc', 'abc@gmail.com', '4', '1', 'tpdy', '70b4269b412a8af42b1f7b0d26eceff2', '3265489562', 'far5.jpg', NULL, '2019-04-26 08:46:23', '2019-04-26 08:46:23', '1', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_code` (`product_code`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catid`),
  ADD UNIQUE KEY `category` (`category`);

--
-- Indexes for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD PRIMARY KEY (`cityid`),
  ADD UNIQUE KEY `cname` (`cname`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`con_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`distid`),
  ADD UNIQUE KEY `dname` (`dname`);

--
-- Indexes for table `tbl_fdbk`
--
ALTER TABLE `tbl_fdbk`
  ADD PRIMARY KEY (`fd_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productid`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `tbl_recipe`
--
ALTER TABLE `tbl_recipe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reply`
--
ALTER TABLE `tbl_reply`
  ADD PRIMARY KEY (`rply_id`);

--
-- Indexes for table `tbl_upload`
--
ALTER TABLE `tbl_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_city`
--
ALTER TABLE `tbl_city`
  MODIFY `cityid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `con_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `distid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_fdbk`
--
ALTER TABLE `tbl_fdbk`
  MODIFY `fd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_recipe`
--
ALTER TABLE `tbl_recipe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_reply`
--
ALTER TABLE `tbl_reply`
  MODIFY `rply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_upload`
--
ALTER TABLE `tbl_upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
