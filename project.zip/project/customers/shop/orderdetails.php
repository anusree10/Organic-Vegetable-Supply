<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../../config.php';
CheckLogout();
include 'header.php';
 
?>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CCCC;
}
</style>
 <link rel="stylesheet" href="../css/table-style.css">  
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2><font color="#000033" size="+2">Order Details</font></h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							<th>Image</th>
							<th>Product Name</th>
							
							<th>Price</th>
						    <th>Date</th>
							
							
						  </tr>
						</thead>
						<?php
  
  $qry="select * from tbl_payment,products,users where tbl_payment.product_id=products.id and users.id='$uid'";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
     <td><img src="images/<?php echo $row['product_img_name'];?>"width="100px" height="100px" />&nbsp;</td>
	<td><?php echo $row['product_name'];?>&nbsp;</td>
	
	<td><?php echo $row['price'];?>&nbsp;</td>
	<td><?php echo $row['date'];?>&nbsp;</td>
	
	
	
	  
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						</div>
						</div>
					
						</div>
						