<?php
//$con=mysqli_connect("localhost","root","","store");
include '../query.php';

//$qry1="select * from users";
//$res=setData($qry1);
if(isset($_POST['submit']))
{
extract($_POST);
//$uid=$row[0];
$cname=$_POST['cardname'];
$cno=$_POST['cardnumber'];
$month=$_POST['expmonth'];
$year=$_POST['expyear'];
$cvv=$_POST['cvv'];
$qry="insert into tbl_payment(user_id,card_name,card_no,exp_month,exp_year,cvv) values('$uid','$cname','$cno','$month','$year','$cvv')";
setData($qry);
echo "<script>window.onload=function(){alert('Payment Completed....!');window.location='checkout.php';}</script>";
}
?>