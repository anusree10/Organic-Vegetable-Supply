<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../../config.php';
CheckLogout();
include 'header.php';

?>
<style>
.btn-increment-decrement {
    display: inline-block;
    padding: 5px 0px;
    background: #e2e2e2;
    width: 30px;
    text-align: center;
    cursor:pointer;
}
.input-quantity {
	border: 0px;
    width: 30px;
    display: inline-block;
    margin: 0;
    box-sizing: border-box;
    text-align: center;
}
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC99;
}
</style>

<h1 align="center"><font size="+3" color="#000000">View Cart</font></h1>
<br><br>
<div class="cart-view-table-back">
<form method="post" action="">
<center><table width="100%"   cellpadding="6" cellspacing="0"><thead><tr><th>Image</th><th>Name</th><th>Quantity</th><th>Price</th><th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remove</th></tr></thead></center>
  <tbody>
 <?php
   $con=mysqli_connect("localhost","root","","store");
  $qry="select * from products,tbl_cart where products.id=tbl_cart.product_id AND tbl_cart.user_id='$uid'";
  //$qry="select * from tbl_cart,products where cart_id='".$_GET['id']."'    ";
  $res=setData($qry);
  while($row=mysqli_fetch_array($res))
  {
  $pid=$row['product_id'];
  ?>
  <tr>
  
  
    <td><span class="style11"><img src="../../images/<?php echo $row['product_img_name'];?>"width="100px" height="100px" />&nbsp;</span></td>
    
    <td><span class="style11"><?php echo $row['product_name'];?>&nbsp;</span></td>
   
   
	 <td><span class="cart-info quantity">
                    <div class="btn-increment-decrement" onClick="decrement_quantity(<?php echo $row['quantity']; ?>, '<?php echo $item["price"]; ?>')">-</div>
					

<input class="input-quantity"
                        id="input-quantity-<?php echo $row["cart_id"]; ?>" value="1kg" ><div class="btn-increment-decrement"
                        onClick="increment_quantity(<?php echo $item["cart_id"]; ?>, '<?php echo $row["price"]; ?>')">+</div>
                </span></td>
    <td><span class="style11"><?php echo $row['price'];?>&nbsp;</span></td>
	
    
    
    <td><span class="style11"><a href="delete.php?id=<?php echo $row[0];?>" class="button">Delete</a></span></td>
  </tr>
 
  
	
		
    <?php
  }
  ?>
  
  
   <tr><td colspan="5"><span style="float:right;text-align: right;">Total Amount Payable :<?php echo  $row['price'];  ?></span></td></tr>
  
    
    <tr><td colspan="5"><a href="index.php" class="button">Add More Items</a><a href="checkout.php?pid=<?php echo $pid;?>&uid=<?php echo $uid;?>"class="button">Order Now</td></tr>
  </tbody>
</table>


</form>



</body>
</html>

  