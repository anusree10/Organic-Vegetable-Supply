
    
<?php
session_start();
include '../../config.php';


CheckLogout();

$uid=$_SESSION['id'];

include 'header.php';
 
?>


<?php
if(isset($_GET['error']))
{
   $text=$_GET['error'];

  ?>
  <div onclick="this.style.display='none';" style="padding:20px;background-color:#FF0000;color:#FFFFFF">
  <strong><?php echo $text; ?></strong>
  </div>
  <?php
  
}
?>
 <link href="css/stylezoom.css" rel="stylesheet" type="text/css">
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Feature Products</h3>
    		</div>
            
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
          <?php
		  $con=mysqli_connect("localhost","root","","store");
		  //include '../query.php';
  $qry="select * from products,tbl_category where products.catid=tbl_category.catid";
  //$qry="SELECT product_code, product_name, product_desc, product_img_name, price FROM products ORDER BY id ASC";
		  $res=setData($qry);
		  while($row=mysqli_fetch_array($res))
		  {
		  ?>
				<div class="grid_1_of_4 images_1_of_4">
				<div class="zoom">
					<img src="images/<?php echo $row['product_img_name'];?>"width="200px" height="200px" /></div>
					 <h2><font size="+1"><?php echo $row['product_name'];?> </h2>
					 <p><?php echo $row['product_desc'];?></p>
					 <p><span><font color="#000000"><?php echo $row['price'];?></font></span></p>
					 <div class="product-footer">
                <div class="float-right">
                    Quantity &nbsp;<input type="text" name="quantity" value="<?php echo $row['quantity'];?>"
                        size="2" class="input-cart-quantity" />
                </div>
				</div>
					
					  <div class="button"><span><img src="<?php echo $row['price'];?>" alt="" /><center><a href="cartaction.php?id=<?php echo $row[0];?>&uid=<?php echo $uid;?>" class="cart-button">Add to Cart</a></span> </div>
					  <div class="button"><span><img src="<?php echo $row['price'];?>" alt="" /><a href="checkout.php" class="cart-button">Buy now</a></span> </div>
				</div>
                <?php
				}
		?>
          
          
          
          
          
				
			</div>
			
    </div>
 </div>
</div>




</body>
</html>
