<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_cart where product_id=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:cart.php');

?>