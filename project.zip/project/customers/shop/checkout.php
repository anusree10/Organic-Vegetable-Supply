<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
$pid=$_REQUEST['pid'];
include '../../config.php';
CheckLogout();
include 'header.php';

?>
<?php
$qry="select * from users,tbl_district,tbl_city where users.district=tbl_district.distid and users.city=tbl_city.cityid and users.id='$uid'";

  $res=setData($qry);
  while($row1=mysqli_fetch_array($res))
  {


$fname=$row1['first_name'];
$lname=$row1['last_name'];	
$email=$row1['email'];
$street=$row1['street'];
$phone=$row1['phone'];


?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/pay.css">

</head>
<body>

<center><h2><font color="#000000" size="+3">Checkout Form</font></h2></center>
<br>

<div class="row">
  <div class="col-75">
    <div class="container">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js1/jquery.min.js"></script>
	<script src="js1/oh-autoval-script.js"></script>
    <div class="regisFrm">
      <form  onsubmit="return" class="oh-autoval-form" method="post">
      
        <div class="row">
          <div class="col-50">
            <h3><font color="#000000" size="+2">Billing Address</font></h3>
			<br>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="firstname"  value="<?php echo $fname; echo $lname; ?>" disabled >
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" value="<?php echo $email; ?>" disabled>
            
			
<?php
	$qry="select * from tbl_district";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	$district=$row1['dname'];
	?>
	<?php }?>
            <div class="row">
              <div class="col-50">
                <label for="district">District</label>
                <input type="text" id="state" name="state" value="<?php echo $district; ?>" disabled>
              </div>
              
            </div>
			<?php
	$qry="select * from tbl_city";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	$city=$row1['cname'];
	?>
	<?php }?>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" value="<?php echo $city; ?>" disabled>
			<label for="adr"><i class=""></i> Street</label>
            <input type="text" id="adr" name="street" value="<?php echo $street; ?>" placeholder="542 W. 15th Street" disabled="disabled">
			
          </div>

          <div class="col-50">
            <h3><font color="#000000" size="+2">Payment</font></h3>
			<br>
			
			
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="John More Doe" required>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" class="av-number" av-message=" Please enter valid card number" placeholder="1111-2222-3333-4444" required>
            <label for="expmonth">Exp Month</label>
            <select style="width:633px; height:40px;" id="expmonth" name="expmonth" placeholder="MONTH" required>
			<option value="january">January</option>
			<option value="february">February</option>
			<option value="march">March</option>
			<option value="april">April</option>
			<option value="may">May</option>
			<option value="june">June</option>
			<option value="july">July</option>
			<option value="auguest">Auguest</option>
			<option value="september">September</option>
			<option value="october">October</option>
			<option value="november">November</option>
			<option value="december">December</option>
			</select>
			<br><br>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <select style="width:300px; height:40px;" id="expyear" name="expyear" placeholder="2018" required>
				<option value="2018">2018</option>
				<option value="2019">2019</option>
				<option value="2020">2020</option>
				<option value="2021">2021</option>
				<option value="2022">2022</option>
				<option value="2023">2023</option>
				</select>
				
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" class="av-number" av-message=" Three numbers only" placeholder="cvv" required>
              </div>
            </div>
          </div>
     
        </div>
        
        <input type="submit" name="submit" id="submit" value="Continue to checkout" class="btn">
		<?php }?>
      </form>
    </div>
  </div>
 <?php
//$con=mysqli_connect("localhost","root","","store");
//include '../query.php';

//$qry1="select * from users";
//$res=setData($qry1);
if(isset($_POST['submit']))
{
extract($_POST);
//$uid=$row[0];
$cname=$_POST['cardname'];
$cno=$_POST['cardnumber'];
$month=$_POST['expmonth'];
$year=$_POST['expyear'];
$cvv=$_POST['cvv'];
$da=date('Y-m-d');
$qry="insert into tbl_payment(user_id,product_id,card_name,card_no,exp_month,exp_year,cvv,date) values('$uid','$pid','$cname','$cno','$month','$year','$cvv','$da')";
setData($qry);
echo "<script>window.onload=function(){alert('Payment Completed....!');window.location='orderdetails.php';}</script>";
}
?>
</div>

</body>
</html>
