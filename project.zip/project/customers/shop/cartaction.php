<?php
include '../query.php';

$pid=$_REQUEST['id'];
$uid=$_REQUEST['uid'];
$da=date('Y-m-d');

$qry="select * from tbl_cart where user_id='$uid' and product_id='$pid'";
//$qry="select * from tbl_cart,users where tbl_cart.user_id=users.id and user_id='$uid' and product_id='$pid'";
$res=setData($qry);
if(mysqli_num_rows($res)>0)
{

header("location:index.php?error=Product already in the cart and check your cart...");
}
else
{
$qry="insert into tbl_cart(user_id,product_id,date) values('$uid','$pid','$da')";
$res=setData($qry);
header('location:cart.php'); 
//echo "<script>window.onload=function(){alert('Product added to cart');window.location='cart.php?pid=$pid';}</script>";
}
?>