

<?php 
include '../config.php';


	unset($_SESSION["id"]);

session_destroy();
header("location:../../project/index.php");
?> 






