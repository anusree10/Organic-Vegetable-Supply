<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Product Pricing Plans Widget Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

</head>
<body>
<div class="main">
 

			<div id="small-dialog" class="mfp-hide agile_book_form">
				<h2>Shipping Order Form</h2>
				<form action="payment.php" method="post">
					<div class="wthree_pop_up_left"> 
						<h4>Your Name</h4>
						<input type="text" name="Name" placeholder="Your Name" required=""/>
						<h4>Your Email</h4>
						<input type="email" name="Email" class="email" placeholder="Email" required=""/>
						
					</div>
					<div class="wthree_pop_up_left"> 
						<div class="wthree_pop_up_left1">
							<h4>Your Card Number</h4>
							<input type="text" name="Name" placeholder="Card number" required=""/>
							<h4>Country</h4>
							<select id="country1" onChange="change_country(this.value)" class="frm-field required sect">
								<option value="null">Australia</option>
								<option value="null">America</option> 
								<option value="null">Russia</option>					
								<option value="null">Japan</option>								
							</select>
						</div>
						<div class="wthree_pop_up_left1_sub">
							<img src="images/card.png" alt=" " />
						</div>
						<div class="clear"> </div>
						<div class="w3_delivery_address">
							<h5>Delivery Address</h5>
							<h4>Email Address</h4>
							<input type="email" name="Email" placeholder="Your Email" required=""/>
							<h4>Street Line Address</h4>
							<input type="text" name="Street Line Address" placeholder="Street Line Address" required=""/>
							<h4>PIN / Zip Code</h4>
							<input type="text" name="Pin" placeholder="1234" required=""/>
							<a href="productbuy.php"><input type="submit" value="Order Now"></a>
						</div>
					</div>
					<div class="clear"> </div>
				</form>
			</div>
			<!-- pop-up-box -->
			<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
			<!--//pop-up-box -->
			<script>
				$(document).ready(function() {
					$('.popup-with-zoom-anim').magnificPopup({
						type: 'inline',
						fixedContentPos: false,
						fixedBgPos: true,
						overflowY: 'auto',
						closeBtnInside: true,
						preloader: false,
						midClick: true,
						removalDelay: 300,
						mainClass: 'my-mfp-zoom-in'
					});														
				});
			</script>
		</div>

		
	</div>
</body>
</html>