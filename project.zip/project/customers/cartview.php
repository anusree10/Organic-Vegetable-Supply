<?php
session_start();


 include 'query.php';
?>
<link href="css/style1.css" rel="stylesheet" type="text/css" media="all"/>
 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<center><br><h3>Feature Products</h3>
    		</div>
            
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
          <?php
 $qry="select * from tbl_product,tbl_category where tbl_product.catid=tbl_category.catid";
		  $res=setData($qry);
		  while($row=mysqli_fetch_array($res))
		  {
		  ?>
				
				<center>
					<img src="../images/<?php echo $row['image'];?>"width="100px" height="100px" />
					 <h2><?php echo $row['title'];?> </h2>
					 <p><?php echo $row['description'];?></p>
					 <p><span><?php echo $row['rate'];?></span></p>
					  <div class="button"><span><img src="<?php echo $row['rate'];?>" alt="" /><a href="cart.php?id=<?php echo $row[0];?>&uid=<?php echo $uid;?>" class="cart-button">Add to Cart</a></span> </div>
				</div>
                <?php
				}
		?>
          
          
          
          
          
          
				
			</div>
			
    </div>
 </div>
</div>
   
</body>
</html>

