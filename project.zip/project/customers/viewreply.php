<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<style>
body{
    font-family: Arial;
    width: 1362px;
	background-color:#00CC99;
}
</style>

 <link rel="stylesheet" href="css/table-style.css">  
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2>Farmer's message replys</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							<th>Farmer Name</th>
							<th>Email</th>
							
							<th>Reply</th>
							
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_reply,users where tbl_reply.farmer_id=users.id and tbl_reply.user_id='$uid'";
  //$qry="select * from tbl_reply,tbl_contact,users where tbl_reply.farmer_id=users.id and tbl_reply.con_id=tbl_contact.con_id and tbl_reply.user_id='$uid";
  
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row['first_name']; echo $row['last_name'];?>&nbsp;</td>
	<td><?php echo $row['email'];?>&nbsp;</td>
	
	<td><?php echo $row['reply'];?>&nbsp;</td>
	
	  
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						</div>
						</div>
					
						</div>
						