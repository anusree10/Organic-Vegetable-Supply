<?php
session_start();
//include '../query.php';
$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();
include 'header.php';
 
?>
<!DOCTYPE html>
<html>
<head>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 1250px;
  
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

<h2 style="text-align:center">Recipes</h2>
 <?php
  
   
		  $con=mysqli_connect("localhost","root","","store");
		  $qry="select * from tbl_recipe";
		   $res=setData($qry);
		  while($row=mysqli_fetch_array($res))
		  {
		 
		  ?>
<div class="card">
 <div class="grid_1_of_4 images_1_of_4">
		 <img src="../farmer/images/<?php echo $row['rec_img_name'];?>"  style="width:1200px; height:360px;" />
  
 <h2><font size="+1"><?php echo $row['rec_title']?></h2>
 
  <p><?php echo $row['rec_desc']?> </p>
  <p><button>View Recipe</button></p>
</div>
<?php }?>
</body>
</html>
