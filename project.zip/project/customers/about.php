<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
  <?php
include '../config.php';


CheckLogout();




?> 

<!DOCTYPE html>
<html lang="zxx">

<head>
  <title>Organic Vegetable Supply</title>
  <!--meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Organic Store Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
         Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
  />
  <script>
    addEventListener("load", function () {
      setTimeout(hideURLbar, 0);
    }, false);


    function hideURLbar() {
      window.scrollTo(0, 1);
    }
  </script>
  <!--booststrap-->
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all">
  <!--//booststrap end-->
  <!-- font-awesome icons -->
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <!-- //font-awesome icons -->
  <!--stylesheets-->
  <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
  
  <link href="css/styleayur.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
  <!--//stylesheets-->
  <link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Patrick+Hand" rel="stylesheet">
  <link href="//fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
  <script src="js1/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js1/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js1/nav.js"></script>
<script type="text/javascript" src="js1/move-top.js"></script>
<script type="text/javascript" src="js1/easing.js"></script>
<script type="text/javascript" src="js1/nav-hover.js"></script>
  <script type="text/javascript">
  

  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
 <div class="header_top_right"><script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#language') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>

		 
		  <div class="currency" title="currency">
					
		    <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#currency') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown').removeClass('active');
				});

			});

		</script>
		
		</div>
		
<div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
 
 <div class="banner-left-side" id="home">
    <!-- header -->
    
      <!-- nav -->
      
	<div class="menu">
	  <ul id="dc_mega-menu-orange" class="dc_mm-orange">
		 <li><a href="user_home.php">Home</a></li>
      <li>
            <a href="about.php">About</a>          </li>
			
 <!--li><a href="#">Tips & Advice</a>
    <ul>
			    <li><a href="gg.php">Upload</a></li>
				 <li><a href="">View</a></li>
				 </ul>
            
  </li-->
 
  <li>
              <a href="shop/index.php">Buy Products</a>			  </li>
			  <li>
            <a href="shop/cart.php">My Cart</a></font>          </li>
			
			<li><a href="">Message</a>
  <ul>
  <li><a href="profilecard.php">Send message</a></li>
   <li><a href="viewreply.php">View Reply</a></li>
   </ul></li>
   
  <li><a href="shop/orderdetails.php">Order</a></li>
			
  <li><a href="feedback.php">Feedback</a></li>

  
  
			    <li><a href="profile.php">Profile</a></li>
				 <li><a href="logout.php">Logout</a></li>
				

  <div class="clear"></div>
</ul>
</div>

<div class="headder-top">
<div class="clear"></div>
	</div>
	<div class="header_bottom">
	
	
		<div class="header_bottom_left">
		<br><br>
 <center><font size="+2" style="background-color:#FF9900" color="#FFFFFF">
 <?php
		 if(isset ($_SESSION['email']))
		 {
		 echo "Welcome: ".$_SESSION['email'];
		 }
		
?>

</font></center>		
				
	  </div>
			
		  
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
              <section class="slider">
				  <div class="flexslider">
					
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
</div>





<!--body>
  <!-- //banner -->
 
		
    <!-- //header -->
 
    
        <center><br><br><br><br>
	
		
        <div class="banner-right-txt">
          
         <h4><font color="#990000" size="+4">About the site.....</font></h4>
        </div>
        <div class="slide-info-txt">
          <p>If some consumers believe that it's better from the point of view of their health to have organic food, God bless them. Let them buy it. Let them pay a bit more.Organically grown produce cannot be grown with the use of chemically based fertilizers or synthetic pesticides. It does not necessarily mean that no pesticides were used, but any pesticides would have to be regulated and non-synthetic. It is also not allowed to be genetically modified, and has not been irradiated.

</p>
        </div>
      </div>
    </div>
  </div>
  <!-- //banner -->
 
  <!-- store-info -->
  
  <!--footer-copy-right -->
  
  <!--//footer-copy-right -->

</body>

</html>