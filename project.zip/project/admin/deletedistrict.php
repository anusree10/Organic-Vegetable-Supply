
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_district where distid=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:districtview.php');

?>