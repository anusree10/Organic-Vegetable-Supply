
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_city where cityid=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:viewcity.php');

?>