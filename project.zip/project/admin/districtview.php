
<?php
include '../config.php';
CheckLogout();
?> 
<?php
include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>District</li><i class="fa fa-angle-right"></i>View District</li>
            </ol>
<div class="agile-grids">	
				<!-- tables -->
				
				<div class="agile-tables">
					<div class="w3l-table-info">
					  <center><h2>District View</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>District No</th>
							<th>District Name</th>
							<th>Operation</th>
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_district";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row[1];?>&nbsp;</td>
	<td><span class="style2 style1">
      
	  <a href="deletedistrict.php?id=<?php echo $row[0];?>"><input type="submit" name="delete" value="DELETE" />
      &nbsp;</span></td>
	  
  </tr>
  <?php $c++;
  }
  ?>
					  </table>
					</div>
				  
		
				 

				</div>
				<!-- //tables -->
			</div>
<!-- script-for sticky-nav -->
<?php
		include('footer.php');
		?>
		