<?php
include '../config.php';
CheckLogout();
?> 
<?php 
if(isset($_POST['submit']))
{
	extract($_POST);
	
	$qry="insert into tbl_category(category)values('$Name')";
	setData($qry);
	header('location:addcategory.php');
}
?>
<?php
include('header.php');
?>
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Category</li><i class="fa fa-angle-right"></i>Add Category</li>
            </ol>
<!--four-grids here-->
		
					<div class="clearfix"></div>
				</div>
				
				<div align="center">
<form onsubmit="return" class="oh-autoval-form" method="POST">
<h1> Category </h1>
 <tr>
    <td><div align="center"><strong>Name</strong>
      <label>
        <label>

      </label>
        <input type="text" name="Name" id="Name" class="av-name" av-message="Must be lettrs and enter atleast three charecters">
    </div></td>
    <td></label>
      <p>
        <label>
        <input type="submit" name="submit" id="ADD" value="ADD" onClick="return validate()"  />
        </label>
        <label></label>
      </p></td>
  </tr>
   
</form>
<br><br>


</div>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
				 

	
							</tbody>
						</table>
					</div>
			</div>
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
<?php
include('footer.php');
?>
		