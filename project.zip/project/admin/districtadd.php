<?php
include '../config.php';
CheckLogout();
?> 
<?php 
if(isset($_POST['submit']))
{
	extract($_POST);
	
	$qry="insert into tbl_district(dname)values('$District')";
	$res=setData($qry);
	echo "<script>window.onload=function(){alert('District added....!');window.location='districtadd.php';}</script>";
	//header('location:districtadd.php');
}
?>
<?php
include('header.php');
?>
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>District</li><i class="fa fa-angle-right"></i>Add District</li>
            </ol>
<!--four-grids here-->
		
					<div class="clearfix"></div>
				</div>
				
				<div align="center">
<form onsubmit="return" class="oh-autoval-form" method="POST">
<div class="container">
<h1> Add District </h1>
 <tr>
    <td><div align="center"><strong>District Name</strong>
      <label>
        <label>

      </label>
        <input type="text" name="District" id="District" class="av-name" av-message="Must be lettrs and enter atleast three charecters">
    </div></td>
    <td></label>
      <p>
        <label>
        <input type="submit" name="submit" id="ADD" value="Add District" onClick="return validate()"  />
        </label>
        <label></label>
      </p></td>
  </tr>
   
</form>
<br><br>


</div>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
				 

	
							</tbody>
						</table>
					</div>
			</div>
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
<?php
include('footer.php');
?>
		