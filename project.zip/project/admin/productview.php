<?php
include '../config.php';
CheckLogout();
include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Product</li><i class="fa fa-angle-right"></i>View Product</li>
            </ol>
<div class="agile-grids">	
				<!-- tables -->
				
				<div class="agile-tables">
					<div class="w3l-table-info">
					  <center><h2>Product View</h2></center>
					    <table border="0" id="table">
						<thead>
						  <tr>
							<th>Product No</th>
							<th>Category Name</th>
							<th>Product Quantity</th>
							<th>Product Name</th>
							<th>Description</th>
							
							<th>Price</th>
							<th>Image</th>
							
						  </tr>
						</thead>
						 <?php
  //include('../query.php');
  $con=mysqli_connect("localhost","root","","store");
  $qry="select * from products,tbl_category where products.catid=tbl_category.catid";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row['category'];?>&nbsp;</td>
	 <td><?php echo $row[3];?>&nbsp;</td>
	  <td><?php echo $row[4];?>&nbsp;</td>
	   <td><?php echo $row[5];?>&nbsp;</td>
	    <td><?php echo $row[7];?>&nbsp;</td>
	 <td><img src="images/<?php echo $row['product_img_name'];?>"width="100px" height="100px" />&nbsp;</td>
	   
  </tr>
  <?php $c++;
  }
  ?>
					  </table>
					</div>
				  
		
				 

				</div>
				<!-- //tables -->
			</div>
<!-- script-for sticky-nav -->
		<?php
		include('footer.php');
		?>