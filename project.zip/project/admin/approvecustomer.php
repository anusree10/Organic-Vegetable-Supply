<?php
session_start();
	$con=mysqli_connect("localhost","root","","store");
	
	if(isset($_GET['id']))
	{
		$id=$_GET['id'];
	    $sql="select * from users where id=$id";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$block=$row['status']; 
		if($block== 0)
		{

			$sql="update users set status = '1' where id=$id";
			if(mysqli_query($con,$sql))
				header("location:customerview.php");
			else
				echo "<script>alert(Customer Registration is Approved)</script>";
		}
		if($block== 1)
		{
			$sql="update users set status = '0' where id=$id";
			if(mysqli_query($con,$sql))
				header("location:customerview.php");
			else
				echo "<script>alert(Customer registration is Blocked)</script>";
		}
	}
?>