<?php

include '../config.php';
CheckLogout();
include('header.php');
?>

<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Category</li><i class="fa fa-angle-right"></i>View Category</li>
            </ol>
<div class="agile-grids">	
				<!-- tables -->
				
				<div class="agile-tables">
					<div class="w3l-table-info">
					  <center><h2>Category View</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Category No</th>
							<th>Category Name</th>
							<th>Operation</th>
							
						  </tr>
						</thead>
						 <?php
  //include('../query.php');
  $con=mysqli_connect("localhost","root","","store");
  $qry="select * from tbl_category";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    <td><?php echo $row[1];?>&nbsp;</td>
	<td><span class="style2 style1">
     
	  <a href="deletecategory.php?id=<?php echo $row[0];?>"><input type="submit" name="delete" value="DELETE" />
      &nbsp;</span></td>
  </tr>
  <?php $c++;
  }
  ?>
					  </table>
					</div>
				  
		
				 

				</div>
				<!-- //tables -->
			</div>
<!-- script-for sticky-nav -->
<?php
		include('footer.php');
		?>
		