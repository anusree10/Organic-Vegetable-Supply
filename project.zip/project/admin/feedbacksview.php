
<?php
include '../config.php';
CheckLogout();
?> 
<?php
include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Response</li><i class="fa fa-angle-right"></i>Feedbacks</li>
            </ol>
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2>Responses</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							
							
							<th>UserName</th>
							<th>Email</th>
							<th>Feedback</th>
							<th>SendingDate</th>
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_fdbk,users where tbl_fdbk.user_id=users.id";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    
	
	<td><?php echo $row['first_name'];?>&nbsp;</td>
	<td><?php echo $row['email'];?>&nbsp;</td>
	<td><?php echo $row['text'];?>&nbsp;</td>
	 <td><?php echo $row['date'];?>&nbsp;</td> 
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						</div>
						</div>
						</div>
						<?php
		include('footer.php');
		?>
		