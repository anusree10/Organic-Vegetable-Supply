
<?php
include '../config.php';
CheckLogout();
?> 
<?php
include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Response</li><i class="fa fa-angle-right"></i>Feedbacks</li>
            </ol>
<div class="agile-grids">	
				<!-- tables -->
			<center>
				<div class="agile-tables">
					<div style="width:80%;">
					  <center><h2>Responses</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl.No</th>
							
							
							<th>Message</th>
							<th>Reply</th>
							
							
						  </tr>
						</thead>
						 <?php
  
  $qry="select * from tbl_reply,tbl_contact where tbl_reply.con_id=tbl_contact.con_id";
  $res=setData($qry);
  $c=1;
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $c;?></td>
    
	
	<td><?php echo $row['text'];?>&nbsp;</td>
	<td><?php echo $row['reply'];?>&nbsp;</td>
	
  </tr>
  <?php $c++;
  }
  ?>
						</table>
						</div>
						</div>
						</div>
						<?php
		include('footer.php');
		?>
		