
<?php
$id=$_GET['id'];
include('../dbcon.php');
$qry="delete from tbl_category where catid=".$id;
$obj=new Dbcon;
$obj->submitQuery($qry);
header('location:viewcategory.php');

?>