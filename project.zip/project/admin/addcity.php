<?php
include '../config.php';


CheckLogout();




?> 
<?php
include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>City</li><i class="fa fa-angle-right"></i>Add City</li>
            </ol>
		
					<div class="clearfix"></div>
				</div>
	
<div class="container">
<h2><center>Add City</center></h2>
    
<link rel="stylesheet" type="text/css" href="../css/style.css">
		
<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
<form method="post">
<table width="285" height="102">
  <tr>
    <td width="76" height="42"><span class="style1">District&nbsp;</span></td>
    <td width="197"><span class="style1">
      <select name="dist" id="dist" style="width:95%;padding: 10px 10px 10px 10px;">
        <option value="0">---Select---</option>
        <?php
	
	$qry="select * from tbl_district";
	$res=setData($qry);
	while($row=mysqli_fetch_array($res))
	{
	?>
        <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
        <?php
	}
	?>
        </select>
    </span></td>
  </tr>
  <tr>
    <td height="24">City&nbsp;</td>
    <td><span class="style1">
      <input type="text" name="city" id="city" class="av-name" av-message="minimum 3 characters and alphabets only" required>
      &nbsp;</span></td>
  </tr>
  
  <tr>
    <td height="26" colspan="2"><div align="center"><input type="submit" name="submit" value="Add City" onClick="return validate()"/></div></td>
    </tr>
</table>
</form>
<?php
if(isset($_POST['submit']))
{
extract($_POST);
$qry="insert into tbl_city(distid,cname) values('$dist','$city')";
setData($qry);
echo "<script>window.onload=function(){alert('City added....!');window.location='addcity.php';}</script>";
}
?>

</div>
							</tbody>
						</table>
					</div>
			</div>
		  <div class="clearfix"></div>
	  </div>
	  
<?php
include('footer.php');
?>
		