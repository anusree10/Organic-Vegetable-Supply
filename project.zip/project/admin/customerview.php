<?php

session_start();

$uid=$_SESSION['id'];
include '../config.php';
CheckLogout();

include('header.php');
?>
<ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="admin_home.php">Home</a><i class="fa fa-angle-right"></i>Category</li><i class="fa fa-angle-right"></i>View Category</li>
            </ol>
<div class="agile-tables">
					<div class="w3l-table-info">
					  <center><h2>Customers View</h2></center>
					    <table id="table">
						<thead>
						  <tr>
							<th>Sl NO</th>
							<th>First Name</th>
							
							<th>Email</th>
							<th>District</th>
							<th>city</th>
							<th>Street</th>
							<th>Phone</th>
							<th>Operations</th>
							
							
						  </tr>
						</thead>
						 <?php
 
  //$con=mysqli_connect("localhost","root","","store");
  //$qry="select * from users as U, tbl_district as D, tbl_city as C where U.district=D.distid and U.city=C.cityid and role=1";
  $qry="select * from users,tbl_city,tbl_district where users.city=tbl_city.cityid and users.district=tbl_district.distid and users.role=2";
  //$qry1="select * from tbl_district,users where users.district=tbl_district.distid and users.role=1";
  //$qry="select * from users where role=1";
    $res=setData($qry);
	$c=1;
	
  if(mysqli_num_rows($res))
                               {
                               while($row=mysqli_fetch_array($res))
		                       {
                                if($row['status']==1)
								$btn='UnBlock';
								else
								$btn='Block';
							   
								?>
  <tr>
    <td><?php echo $c;?></td>
    <td><span class="style2 style1"><?php echo $row['first_name'];?>&nbsp;</span></td>
   
	<td><span class="style2 style1"><?php echo $row['email'];?>&nbsp;</span></td>
	<td><span class="style2 style1"><?php echo $row['dname'];?>&nbsp;</span></td>
	<td><span class="style2 style1"><?php echo $row['cname'];?>&nbsp;</span></td>
	<td><span class="style2 style1"><?php echo $row['street'];?>&nbsp;</span></td>
	<td><span class="style2 style1"><?php echo $row['phone'];?>&nbsp;</span></td>
	<td><span class="style2 style1">
	<a href="approvecustomer.php?id='<?php echo $row['id']; ?>'"><button><?php echo $btn; ?></button></a>
	
							  </tr>
                              <?php $c++;
								}
								}
							?>
 
</table>
</form>

				  
		
				 

				</div>
				<!-- //tables -->
			</div>
<!-- script-for sticky-nav -->
<?php
		include('footer.php');
		?>
		