<?php
include '../config.php';
CheckLogout();
?> 
<?php	
include('header.php');

?>

<!--four-grids here-->
		<div class="four-grids" >
					<div class="col-md-3 four-grid" >
						<div class="four-agileits" style="background-color:#FF0066;">
							<div class="icon">
								<i class="glyphicon glyphicon-user" aria-hidden="true"></i>
							</div>
							<div class="four-text" >
								<h3><a href="farmerview.php"  style="color:#FFFFFF;">Farmers</a></h3>
								<h4> 6  </h4>
								
							</div>
							
						</div>
					</div>
					<div class="col-md-3 four-grid"  >
						<div class="four-agileinfo">
							<div class="icon">
								<i class="glyphicon glyphicon-list-alt" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3><a href="customerview.php" style="color:#FFFFFF;">Users</a></h3>
								<h4>5</h4>

							</div>
							
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-w3ls">
							<div class="icon">
								<i class="glyphicon glyphicon-folder-open" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3><a href="productview.php" style="color:#FFFFFF;">Products</a></h3>
								<h4>8</h4>
								
							</div>
							
						</div>
					</div>
					<div class="col-md-3 four-grid">
						<div class="four-wthree">
							<div class="icon">
								<i class="glyphicon glyphicon-briefcase" aria-hidden="true"></i>
							</div>
							<div class="four-text">
								<h3><a href="feedbacksview.php" style="color:#FFFFFF;">Feedbacks</a></h3>
								<h4>3</h4>
								
							</div>
							
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				 

							</tbody>
						</table>
					</div>
			</div>
		  <div class="clearfix"></div>
	  </div>
	  <!--//w3-agileits-pane-->	
<!-- script-for sticky-nav -->
<?php
		include('footer.php');
		?>
		