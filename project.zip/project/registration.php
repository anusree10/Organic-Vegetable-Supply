<?php
session_start();
$sessData = !empty($_SESSION['sessData'])?$_SESSION['sessData']:'';
if(!empty($sessData['status']['msg'])){
    $statusMsg = $sessData['status']['msg'];
    $statusMsgType = $sessData['status']['type'];
    unset($_SESSION['sessData']['status']);
}
?>


<div class="banner">

<br><br>
<script>
    function dist()
    {
        var district=document.getElementById('district').value;
       
        var data=new FormData();
        data.append('did',district);

        $.ajax({
            method:'post',
            url:"districtaction.php",
            processData: false,
            contentType:false,
            data: data,
            success:function(result){
            // alert(result);
             var r=JSON.parse(result);
             $('#city').html("<option value=0>"+"select City"+"</option>");

             for(i=0;i<r.length;i++){
             $('#city').append("<option value="+r[i].id+">"+r[i].value+"</option")
             }
            }
        })

    }
</script>
<div class="container">
<h2><center>Create a New Account</center></h2>
    <?php echo !empty($statusMsg)?'<p class="'.$statusMsgType.'">'.$statusMsg.'</p>':''; ?>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/oh-autoval-style.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/oh-autoval-script.js"></script>
    <div class="regisFrm">
        <form action="userAccount.php" onsubmit="return" class="oh-autoval-form" method="post" >
		<select name="role" id="role">
				 <option value="1">Farmer</option>
				  <option value="2">User</option>
</select><br>
            
            <input type="text" name="first_name" id="first_name" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="FIRST NAME"  required>
			
            <input type="text" name="last_name" class="av-name" av-message="minimum 3 characters and alphabets only" placeholder="LAST NAME"  required>
			
            <input type="email" class="av-email" av-message="enter valid email" name="email" placeholder="EMAIL" required>
			 
             <select id="district" name="district" style=" outline:#666666;border: 2px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 95%;"  required="" onchange="return dist()">
                    <option value="0">DISTRICT</option>
                    <?php 
                    $con=mysqli_connect("localhost","root","","store");
                    $sql="SELECT * FROM tbl_district";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['distid'];
                        $name=$row['dname'];
                        ?>
                        
                        <option value='<?php echo $id ?>'><?php echo $name ?></option>";
                        <?php
                    }
                    ?>
                    </select>
                    </br>
                    <select name="city" id="city" style="outline: none;border: 2px solid #DBDBDB;padding: 10px 10px 10px 10px;font-size: 14px;color: #999;display: block;width: 95%;"  required="">
                    <option value="0">CITY</option>
					
                    </select>  
					  <input type="text" name="street" class="av-name" av-message="Please enter your street" placeholder="STREET"  required>
			<!--input type="text" name="district" placeholder="DISTRICT" required>
			<input type="text" name="city" placeholder="CITY" required-->
			
            <input type="text" name="phone" class="av-mobile" av-message="Enter valid phone number" placeholder="PHONE NUMBER" required>
			<input type="file" name="image" id="image" class="av-image" av-message="Image validation">
			
			
            <input type="password" class="av-password" av-message="Must be enter one capital letter, special charecter and number." name="password" placeholder="PASSWORD" required >
			
            <input type="password" name="confirm_password"  placeholder="CONFIRM PASSWORD" required="">
            <div class="send-button">
                <input  type="submit" name="signupSubmit" value="CREATE ACCOUNT">
            </div>
        </form>
		 <p>Already have an account? <a href="index.php">Sign in</a></p>
    </div>
</div>