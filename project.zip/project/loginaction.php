<?php
session_start();
$con=mysqli_connect("localhost","root","","store"); //database connection page

if(isset($_POST["loginSubmit"]))
{
    

        
        
    
	$username=$_POST["email"];   
	$pwd=md5($_POST['password']);
	$status=$row['status'];	
	 
       
	$sql="select * from users where email='$username' and password ='$pwd'"; 
	//value querried from the table
	//echo $sql;
	$res=mysqli_query($con,$sql);
	$fetch = mysqli_fetch_array($res);
	//query executing function
	 if($res)
{
	
		if($fetch['role']==0)   
		{
		  session_start();
			///$_SESSION["name"]=$fetch['name'];
			$_SESSION["id"]=$fetch['id'];
			$_SESSION["email"]=$username;	// setting username as session variable 
			header("location:admin/admin_home.php");	//home page or the dashboard page to be redirected
	    }
	   elseif($fetch['role']==1)   
		{
		$_SESSION["email"]=$username;	// setting username as session variable 
		$_SESSION["id"]=$fetch['id'];
	    header("location:farmer/farmer_home.php");
	    }
       elseif($fetch['role']==2)   
		{
		$_SESSION["email"]=$username;	// setting username as session variable 
		$_SESSION["id"]=$fetch['id'];
	    header("location:customers/user_home.php");
		
	}
	 else {
  $message = "Username and/or Password incorrect.\\nTry again.";
  echo "<script type='text/javascript'>alert('$message');location:index.php</script>";
   //header("location:index.php");
}
	

    
  }
  
}
?>